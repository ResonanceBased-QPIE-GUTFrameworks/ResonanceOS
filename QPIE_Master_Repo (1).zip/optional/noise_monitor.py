import numpy as np

def _rhi(signal: np.ndarray) -> float:
    arr = np.asarray(signal, dtype=float)
    if arr.size < 3 or np.std(arr) == 0:
        return 0.0
    norm = (arr - np.mean(arr)) / (np.std(arr))
    stability = 1.0 / (1.0 + np.var(np.diff(norm)))
    return float(np.round(stability * 100.0, 2))

def _archetype_flags(arr: np.ndarray, z_hi=2.5, z_lo=0.5):
    mu, sd = np.mean(arr), np.std(arr) if np.std(arr) != 0 else 1.0
    z = (arr - mu) / sd
    spikes = np.sum(np.abs(z) > z_hi)           # spike highs (surges)
    lows = np.sum(np.abs(z) < z_lo)             # fenced lows (quiescence pockets)
    sweet = np.sum((np.abs(z) >= z_lo) & (np.abs(z) <= z_hi))  # sweet spots region
    return spikes, lows, sweet

def _trend(arr: np.ndarray, window=100):
    if arr.size < window*2:
        return "→ steady"
    a = _rhi(arr[:window])
    b = _rhi(arr[-window:])
    if b > a + 2.0:
        return "↑ stable"
    elif b < a - 2.0:
        return "↓ fragile"
    return "→ steady"

def analyze_signal(signal):
    """Public-facing monitor: returns high-level status without coordinates."""
    arr = np.asarray(signal, dtype=float)
    if arr.size < 20:
        return {"status": "insufficient data", "trend": "n/a", "archetype": "n/a", "rhi": 0.0}
    rhi = _rhi(arr)
    spikes, lows, sweet = _archetype_flags(arr)
    status = "calm" if rhi >= 75 else ("variable" if rhi >= 50 else "turbulent")
    counts = {"spike highs": spikes, "fenced lows": lows, "sweet spots": sweet}
    archetype = max(counts, key=counts.get)
    return {"status": status, "trend": _trend(arr), "archetype": archetype, "rhi": rhi}
