import numpy as np

def _smoothness(arr):
    return 1.0 / (1.0 + np.mean(np.abs(np.diff(arr))))

def _symmetry(arr):
    mu = np.mean(arr)
    pos = np.mean(arr[arr >= mu]) if np.any(arr >= mu) else 0.0
    neg = np.mean(arr[arr <  mu]) if np.any(arr <  mu) else 0.0
    return 1.0 / (1.0 + abs(pos + neg))

def _variability(arr):
    s = np.std(arr)
    return 1.0 / (1.0 + s)

def _trend(arr, scorer, window=100):
    if arr.size < window*2:
        return "→ steady"
    a = scorer(arr[:window])
    b = scorer(arr[-window:])
    if b > a + 0.02:
        return "↑ stable"
    elif b < a - 0.02:
        return "↓ fragile"
    return "→ steady"

def pattern_sense(signal, include_references=False, references=None):
    arr = np.asarray(signal, dtype=float)
    if arr.size < 20:
        return {"error": "insufficient data"}
    panels = {
        "Smoothness": {"score": float(_smoothness(arr)), "trend": _trend(arr, _smoothness)},
        "Symmetry":   {"score": float(_symmetry(arr)),   "trend": _trend(arr, _symmetry)},
        "Variability":{"score": float(_variability(arr)), "trend": _trend(arr, _variability)},
    }
    summary = {"panels": panels}
    if include_references and references:
        hist_signal, bins = np.histogram(arr, bins=20, density=True)
        closeness = {}
        for name, ref in references.items():
            ref = np.asarray(ref, dtype=float)
            hist_ref, _ = np.histogram(ref, bins=bins, density=True)
            diff = np.linalg.norm(hist_signal - hist_ref)
            closeness[name] = float(np.round(1.0 / (1.0 + diff), 4))
        summary["reference_closeness"] = closeness
    return summary
