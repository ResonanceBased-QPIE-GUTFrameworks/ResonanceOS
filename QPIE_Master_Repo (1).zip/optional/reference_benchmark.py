import numpy as np

def ghz_like_sequence(n=2048, p_entangle=0.48, seed=None):
    rng = np.random.default_rng(seed)
    probs = np.array([p_entangle, (1-2*p_entangle), p_entangle])
    draws = rng.choice(3, size=n, p=[probs[0], probs[1], probs[2]])
    seq = np.where(draws == 1, 0.0, 1.0)
    return seq.astype(float)

def steady_reference(n=2048, val=1.0):
    return np.full(n, float(val))

def random_reference(n=2048, seed=None):
    rng = np.random.default_rng(seed)
    return rng.normal(0.0, 1.0, size=n)

def js_divergence(a, b, bins=30):
    ha, edges = np.histogram(a, bins=bins, density=True)
    hb, _ = np.histogram(b, bins=edges, density=True)
    eps = 1e-12
    ha = ha + eps; hb = hb + eps
    m = 0.5 * (ha + hb)
    def kl(p, q): return np.sum(p * np.log(p / q))
    js = 0.5 * kl(ha, m) + 0.5 * kl(hb, m)
    return float(js)

def ghz_compare_with_permutation(signal, n_perm=1000, seed=None):
    arr = np.asarray(signal, dtype=float)
    if arr.size < 50:
        return {"error": "insufficient data"}
    rng = np.random.default_rng(seed)
    ghz = ghz_like_sequence(n=arr.size, seed=rng.integers(1, 1_000_000))
    rnd = random_reference(n=arr.size, seed=rng.integers(1, 1_000_000))

    js_sig_ghz = js_divergence(arr, ghz)
    js_sig_rnd = js_divergence(arr, rnd)
    observed = js_sig_rnd - js_sig_ghz

    perm_stats = []
    for _ in range(n_perm):
        if rng.random() < 0.5:
            a, b = ghz, rnd
        else:
            a, b = rnd, ghz
        stat = js_divergence(arr, a) - js_divergence(arr, b)
        perm_stats.append(stat)
    perm_stats = np.asarray(perm_stats)
    p_value = float((np.sum(perm_stats >= observed) + 1) / (n_perm + 1))

    summary = {
        "observed_difference": float(np.round(observed, 6)),
        "p_value": float(np.round(p_value, 6)),
        "closeness": {
            "to_GHZ_like": float(np.round(1.0 / (1.0 + js_sig_ghz), 6)),
            "to_Random":   float(np.round(1.0 / (1.0 + js_sig_rnd), 6))
        },
        "interpretation": (
            "Signal aligns more with GHZ-like reference than Random (lower JS divergence)"
            if observed > 0 else
            "Signal aligns more with Random than GHZ-like"
        ),
        "summary": f"Δ(JS_random - JS_ghz)={observed:.4f}, p={p_value:.4f}"
    }
    return summary
